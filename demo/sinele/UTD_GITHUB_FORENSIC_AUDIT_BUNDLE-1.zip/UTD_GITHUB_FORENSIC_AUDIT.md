# UTD GitHub Forensic Audit — Milestone vs Corrected Dynamics

**Audit date:** 2026-10-20  
**Repository:** https://github.com/brayo003/utdmod  
**Branch checked:** `main`  
**HEAD checked:** `afd71ea573e5b9bdd59f5c9e19c9289ddde13a31`  
**Comparison milestone:** `d35ba419593d0870dbeb037cb32283b8f4d92683` (2026-07-15)  
**Scope:** repository commit history, current runtime equations, simulation-lab equations, relevant telemetry claims, and comparison with `utdmod-corrected-dynamics-1.zip`. This is a focused forensic audit of the substrate paths, not a line-by-line audit of all 894-ish repository paths.

## Executive finding

The previous “virgin chunk reaches maximum depth” result is **not evidence that the GitHub runtime milestone has the same defect**. It is evidence that the simulation lab has a depth equation that differs materially from the runtime equation.

The exact root cause is the lab's ungated term:

`depthGrowth = parameters.depthGrowthGain * organization`

A perfectly uniform, inactive grid gets an organization score of about `0.75`, so with `depthGrowthGain = 0.04`, depth receives `+0.03` per tick before other terms. With baseline `B = 0.02`, the lab's depth coupling adds another `+0.0002`, producing the observed first-tick depth increase of `0.0302`.

The GitHub runtime instead gates organization-driven growth by activity:

`depthGrowth = organization * activityGate * (v3FieldDepthGain + depthGrowthGain) * growthFactor`

where `activityGate = A / (1 + A)`. Its baseline-to-depth coupling is also multiplied by `baselinePersistence = 0.2 * activityGate + 0.8 * memoryGate`. For a virgin state with `A=M=D=0`, both gates are zero, so the uniform-field organization score cannot create depth. In that state, runtime `dD = 0` (assuming zero spatial gradients and no external/transport input).

**Anti-diffusion is not the cause of this virgin-depth result.** Anti-diffusion acts on the memory Laplacian; a uniform zero-memory field has a zero memory Laplacian. The defect is the lab's missing activity/history gate on depth growth.

## 1. What is actually on GitHub?

- `main` HEAD is `afd71ea573e5b9bdd59f5c9e19c9289ddde13a31` (2026-09-27).
- Comparing `d35ba419` (2026-07-15) to `main` reports five commits, but the changed files are `LICENSE`, `README.md`, and `docs/INDEX.md`; no Java source file changed in that comparison.
- Current GitHub runtime `src/main/java/com/utdmod/tension/FieldDerivative.java` has Git blob SHA `345fe462277c6059a41f9e0efb59e7534d7597eb`.
- The same runtime file in `utdmod-corrected-dynamics-1.zip` has the exact same Git blob SHA. The runtime equation file in that ZIP is byte-for-byte identical to GitHub's current version.
- `src/main/java/com/utdmod/tension/ParameterSet.java` also has the same Git blob SHA in GitHub and the corrected ZIP: `4aa013ec8d48bdabf3110a89f9745595580418f9`.

Therefore the corrected ZIP's changes to anti-diffusion and activation decay are in the **simulation-lab implementation**, not the Minecraft runtime. They were not applied to GitHub.

## 2. Equation-by-equation comparison

### A. Field depth / virgin-state semantics

**GitHub runtime** — `src/main/java/com/utdmod/tension/FieldDerivative.java`, approximately lines 97–124:

- Computes `activityGate = A / (1 + A)` and `memoryGate = M / (1 + M)`.
- Gates organization-driven depth growth with `activityGate`.
- Gates baseline-to-depth inflow using `baselinePersistence = 0.2 * activityGate + 0.8 * memoryGate`.
- With `A=M=D=0`, no input, no transport and zero spatial gradients, `dD=0`. Baseline resting recovery alone does not create depth.

**GitHub simulation lab** — `simulation_lab/src/GridSimulationV2.java`, approximately lines 800–811:

- Uses `depthGrowth = parameters.depthGrowthGain * organization` without an activity/history gate.
- The organization functional rewards spatial uniformity even when the field is inactive.
- At a uniform inactive state, organization is approximately `0.75`; with gain `0.04`, growth is `0.03` per tick. A baseline of `0.02` contributes another `0.0002` through the depth coupling row.
- This reproduces the prior lab audit's first-tick `D=0.0302` and rapid rise to the clamp.

**Corrected ZIP simulation lab:** retains the same ungated depth-growth form. Removing memory anti-diffusion did not correct this depth mismatch.

### B. Memory anti-diffusion

**GitHub runtime:** contains activity-gated anti-diffusion:

`-0.15 * memoryFormationGain * (A / (1 + A)) * memoryLaplacian`

plus ordinary diffusion. This sharpening term switches off as activation approaches zero.

**GitHub simulation lab:** contains the older, ungated form:

`-0.15 * memoryFormationGain * memoryLaplacian`

plus ordinary diffusion.

**Corrected ZIP simulation lab:** removes anti-diffusion and retains ordinary memory diffusion. The corrected ZIP runtime still has the GitHub runtime anti-diffusion term because its runtime `FieldDerivative.java` is byte-identical to GitHub.

The earlier checkerboard stress test is relevant to the memory spatial-sharpening mechanism, but it does not explain virgin depth growing from a uniform zero-memory state.

### C. Activation decay

**GitHub runtime:** `v2ActivationDecay` is configured in `ParameterSet`, but `FieldDerivative.computeUnified` does not use it in `dActivation`. Activation does have smaller state-dependent linear dissipation and quadratic dissipation, so this is not “no decay”; it is a mismatch between the declared `v2ActivationDecay` parameter and the runtime equation.

**GitHub simulation lab:** computes `decayA = -parameters.v2ActivationDecay * A` but omits `decayA` from its `dA` expression.

**Corrected ZIP simulation lab:** includes `decayA` in `dA`. This correction is lab-only; the GitHub/runtime derivative is unchanged.

### D. Initial conditions

The lab's `initialize()` method adds tiny signed spatial seeds to activation, memory and depth and initializes baseline near `v2BaselineResting`. The prior depth-rest test deliberately overrode the grid to a uniform virgin state (`A=M=D=0`, with `B=0.02` or `B=0`) to isolate whether the equations generate depth without history. That is a valid controlled test of the lab equation, but it should not be described as a direct Minecraft runtime test.

The runtime `SubstrateState` constructor starts activation, memory, transport, depth, and baseline at zero. The runtime's activity/history gates are therefore especially relevant to the virgin-state question.

## 3. Why the milestone could appear to work

The GitHub telemetry report describes the live substrate at rest as having activation near zero, memory zero, and depth near zero. That claim is consistent with the runtime's gated depth equation. It is not consistent with the simulation lab's ungated organization-to-depth growth equation under the same zero-input initial state.

This points to a **model-fidelity problem**, not proof that the GitHub runtime's virgin-depth behavior is broken. Runtime telemetry and lab simulations cannot be treated as interchangeable until the equations are reconciled.

There are still separate runtime issues to investigate: runtime anti-diffusion remains present; the configured `v2ActivationDecay` is omitted from runtime `dA`; and the previously reported memory-gain/telemetry discrepancy remains unresolved. None of those changes the specific root cause of the lab's virgin-depth failure.

## 4. Decisions and changes discussed so far

| Item | Status | Where it currently stands |
|---|---|---|
| Preserve the GitHub milestone as an untouched reference | **Decision** | No GitHub source changes were made for these experiments. |
| Remove anti-diffusion from the corrected baseline after checkerboard instability tests | **Applied only in corrected lab** | Removed from `simulation_lab` in corrected ZIP; still present in GitHub lab and in runtime. Runtime still has the activity-gated form. |
| Include the configured linear activation-decay term in `dA` | **Applied only in corrected lab** | Corrected lab includes `decayA`; runtime still omits `v2ActivationDecay` from `dA`. |
| Add a separate stability/order variable so organized regions resist new input | **Experimental idea only** | Temporary harness showed the response can be attenuated; not integrated, not approved for merge, and its lifecycle needs validation. |
| Correct virgin-depth semantics in the lab | **Required for lab/runtime fidelity** | Lab depth growth should be gated by evidence of activity/history, as runtime already does, or otherwise be deliberately redesigned and justified. No source edit made. |
| Threshold reachability fix (`T1=0.35`, `T2=0.60`, `T3=0.72`, hysteresis `0.08`) | **Separate local patch only** | Previously packaged in a separate local threshold-fix ZIP; not in GitHub. Do not confuse it with corrected-dynamics ZIP. |
| Resolve memory equation / telemetry mismatch | **Open audit item** | Reported expected steady state and measured memory trajectory disagree. Do not calibrate gains until the exact runtime and telemetry paths are traced. |

## 5. The actual issue and next steps

1. Keep GitHub `main` unchanged as the milestone baseline.
2. Stop using the corrected lab's current depth trajectory as evidence about runtime virgin-state behavior.
3. Align the lab's depth equation with the runtime's activity/history-gated semantics, in a separate experimental branch/copy. This is a model-fidelity correction, not proof that runtime needs the same change.
4. Run the same no-input virgin test against both paths, then compare activity injection, memory retention, depth acquisition, and recovery using identical initial states and parameters.
5. Only after those paths agree should the stability-variable lifecycle test be used to decide whether a new state variable is warranted.
6. Separately decide whether removing anti-diffusion is intended for runtime too. The corrected ZIP does not currently do that; it only removes it from the lab. Do not silently propagate the lab change into the milestone runtime.
7. Trace the configured activation-decay and memory-formation equations in runtime before claiming that the corrected lab validates runtime telemetry.

## Source links

- [GitHub repository main](https://github.com/brayo003/utdmod/tree/main)
- [Runtime FieldDerivative.java](https://github.com/brayo003/utdmod/blob/main/src/main/java/com/utdmod/tension/FieldDerivative.java)
- [Runtime ParameterSet.java](https://github.com/brayo003/utdmod/blob/main/src/main/java/com/utdmod/tension/ParameterSet.java)
- [Runtime SubstrateState.java](https://github.com/brayo003/utdmod/blob/main/src/main/java/com/utdmod/tension/SubstrateState.java)
- [Simulation-lab GridSimulationV2.java](https://github.com/brayo003/utdmod/blob/main/simulation_lab/src/GridSimulationV2.java)
- [Telemetry report](https://github.com/brayo003/utdmod/blob/main/analysis/UTD_TELEMETRY_REPORT.md)
- [Corrected dynamics ZIP used for comparison](sandbox:/mnt/data/utdmod-corrected-dynamics-1.zip)

## Scope and confidence

The central source mismatch is directly established from current GitHub source and exact file hashes. The virgin-state derivative comparison follows directly from those equations and the stated zero-gradient test conditions. This audit does not claim a fresh in-game playtest or a full review of every file in the repository. No GitHub file, branch, commit, issue, or pull request was changed.
