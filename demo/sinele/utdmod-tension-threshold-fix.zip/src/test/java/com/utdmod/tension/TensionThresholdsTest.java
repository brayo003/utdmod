package com.utdmod.tension;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class TensionThresholdsTest {
    @Test
    void chunkThresholdsAreOrderedAndWithinObservationRange() {
        assertTrue(0.0 < TensionThresholds.CHUNK_STRAINED);
        assertTrue(TensionThresholds.CHUNK_STRAINED < TensionThresholds.CHUNK_FRACTURED);
        assertTrue(TensionThresholds.CHUNK_FRACTURED < TensionThresholds.CHUNK_DECOUPLED);
        assertTrue(TensionThresholds.CHUNK_DECOUPLED < 0.8);
    }

    @Test
    void hysteresisDoesNotOverlapAdjacentStateEntryThresholds() {
        assertTrue(TensionThresholds.CHUNK_STRAINED - TensionThresholds.CHUNK_HYSTERESIS >= 0.0);
        assertTrue(TensionThresholds.CHUNK_STRAINED + TensionThresholds.CHUNK_HYSTERESIS < TensionThresholds.CHUNK_FRACTURED);
        assertTrue(TensionThresholds.CHUNK_FRACTURED + TensionThresholds.CHUNK_HYSTERESIS < TensionThresholds.CHUNK_DECOUPLED);
    }

    @Test
    void regionalAndActuatorThresholdsAreReachable() {
        assertTrue(TensionThresholds.REGION_STRAINED < 0.8);
        assertTrue(TensionThresholds.REGION_FRACTURED < 0.8);
        assertTrue(TensionThresholds.CONTAMINATION_MEDIUM < 0.8);
        assertTrue(TensionThresholds.CONTAMINATION_HEAVY < 0.8);
        assertTrue(TensionThresholds.SLEEP_BLOCK < 0.8);
        assertTrue(TensionThresholds.WRAITH_AGGRESSION < 0.8);
    }
}
