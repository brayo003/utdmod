package com.utdmod.tension;

import com.utdmod.config.UTDConfig;
import com.utdmod.core.TensionManager;
import com.utdmod.core.TensionTraceClock;
import com.utdmod.core.TensionTraceLogger;
import com.utdmod.diag.DiagnosticLogs;
import com.utdmod.experiment.ExperimentLogger;
import com.utdmod.experiment.ExperimentTelemetry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Stores local tension data per chunk, persisted across world saves.
 */
public class ChunkTensionData extends PersistentState {
    public enum ChunkState {
        STABLE,
        STRAINED,
        FRACTURED,
        DECOUPLED
    }

    // Shared thresholds are calibrated to the bounded observation metric's reachable range.
    private static final double T1 = TensionThresholds.CHUNK_STRAINED;
    private static final double T2 = TensionThresholds.CHUNK_FRACTURED;
    private static final double T3 = TensionThresholds.CHUNK_DECOUPLED;
    /** Downgrade hysteresis so states persist briefly as tension falls (spatial memory). */
    private static final double STATE_HYSTERESIS = TensionThresholds.CHUNK_HYSTERESIS;

    public static final PersistentState.Type<ChunkTensionData> TYPE = new PersistentState.Type<>(
        ChunkTensionData::new,
        ChunkTensionData::fromNbt,
        null // DataFixer, null for now
    );

    // Map of ChunkPos to chunk state
    private final Map<ChunkPos, ChunkState> chunkStates = new HashMap<>();
    // Map of ChunkPos to recent mining activity (decays over time)
    private final Map<ChunkPos, Double> recentMiningRate = new HashMap<>();
    // Map of ChunkPos to storm active state
    private final Map<ChunkPos, Boolean> stormActive = new HashMap<>();
    // Contamination memory (slow recovery); persisted per chunk
    private final Map<ChunkPos, Double> contaminationPeak = new HashMap<>();
    /** 0 none, 1 medium, 2 heavy; thresholds are defined in TensionThresholds. */
    private final Map<ChunkPos, Byte> contaminationLevel = new HashMap<>();
    // First-class substrate state mirroring the laboratory activation/memory/transport/field-depth structure
    private final Map<ChunkPos, SubstrateState> substrateStates = new HashMap<>();
    // Transient per-tick impulses consumed during substrate integration.
    private final Map<ChunkPos, Double> instantaneousImpulses = new HashMap<>();
    // Map of ChunkPos to last access timestamp (ms) for TTL-based pruning
    private final Map<ChunkPos, Long> lastAccessMs = new HashMap<>();

    public static ChunkTensionData getServerState(ServerWorld world) {
        PersistentStateManager manager = world.getPersistentStateManager();
        return manager.getOrCreate(TYPE, "chunk_tension_data");
    }

    public java.util.Set<ChunkPos> getActiveChunkPositions() {
        return substrateStates.keySet();
    }

    public SubstrateState getOrCreateSubstrateState(ChunkPos pos) {
        touch(pos);
        return substrateStates.computeIfAbsent(pos, ignored -> new SubstrateState());
    }

    public SubstrateState getSubstrateState(ChunkPos pos) {
        touch(pos);
        return substrateStates.get(pos);
    }

    public Map<ChunkPos, SubstrateState> getSubstrateStatesView() {
        return substrateStates;
    }

    public double getLocalTension(ChunkPos pos) {
        SubstrateState ss = substrateStates.get(pos);
        return ss != null ? SubstrateObservationModel.computeLocalTension(ss) : 0.0;
    }

    public double getRecentMiningRate(ChunkPos pos) {
        return recentMiningRate.getOrDefault(pos, 0.0);
    }

    public void setRecentMiningRate(ChunkPos pos, double rate) {
        if (rate <= 0.0) {
            recentMiningRate.remove(pos);
        } else {
            recentMiningRate.put(pos, rate);
        }
        touch(pos);
        markDirty();
    }

    public boolean isStormActive(ChunkPos pos) {
        touch(pos);
        return stormActive.getOrDefault(pos, false);
    }

    public void setStormActive(ChunkPos pos, boolean active) {
        if (!active) {
            stormActive.remove(pos);
        } else {
            stormActive.put(pos, true);
        }
        markDirty();
    }

    public ChunkState getChunkState(ChunkPos pos) {
        touch(pos);
        return chunkStates.getOrDefault(pos, ChunkState.STABLE);
    }

    /**
     * Update ChunkState classification from the derived tension metric.
     * Called by TensionServerTick after computing T(x) from substrate.
     * No tension value is stored — classification only.
     */
    public void updateChunkClassification(ChunkPos pos, double tension, ServerWorld world) {
        ChunkState oldState = getChunkState(pos);
        if (tension <= 0.0) {
            chunkStates.remove(pos);
            stormActive.remove(pos);
        } else {
            updateContaminationMemory(pos, tension);
            ChunkState newState = calculateState(tension, oldState);
            if (newState != oldState) {
                chunkStates.put(pos, newState);
                long wtick = world != null ? world.getTime() : TensionTraceClock.getServerTick();
                com.utdmod.diag.DiagnosticLogs.tensionState(
                    pos, oldState, newState, tension, wtick,
                    "STATE_HYSTERESIS=" + STATE_HYSTERESIS);
                if (world != null) {
                    ExperimentTelemetry.onChunkStateTransition(pos, oldState, newState, tension, wtick);
                    triggerStateTransitionEffects(world, pos, oldState, newState);
                }
            }
        }
        touch(pos);
        markDirty();
    }

    public void addInstantaneousImpulse(ChunkPos pos, double amount) {
        if (amount <= 0.0) {
            return;
        }
        instantaneousImpulses.merge(pos, amount, Double::sum);
    }

    /**
     * Multiplier applied to linear decay term (smaller = slower recovery) when contamination memory active.
     */
    public double getContaminationDecayMultiplier(ChunkPos pos) {
        byte lv = contaminationLevel.getOrDefault(pos, (byte) 0);
        return lv >= 2 ? 0.38 : lv >= 1 ? 0.68 : 1.0;
    }

    public double getContaminationPeak(ChunkPos pos) {
        return contaminationPeak.getOrDefault(pos, 0.0);
    }

    public int getContaminationLevel(ChunkPos pos) {
        return contaminationLevel.getOrDefault(pos, (byte) 0);
    }

    public double consumeInstantaneousImpulse(ChunkPos pos) {
        double impulse = instantaneousImpulses.getOrDefault(pos, 0.0);
        instantaneousImpulses.remove(pos);
        return impulse;
    }

    public void clearInstantaneousImpulses() {
        instantaneousImpulses.clear();
    }

    /**
     * Synchronous gather/apply substrate integration for all scheduled chunks.
     * Reads neighbor state from a tick-start snapshot; writes all updates after every
     * derivative has been computed (laboratory-style double-buffer semantics).
     */
    public void integrateAllSubstrateStates(ServerWorld world, Iterable<ChunkPos> positions) {
        ParameterSet parameters = ParameterSet.runtime();
        Map<ChunkPos, SubstrateState> snapshot = new HashMap<>();
        for (Map.Entry<ChunkPos, SubstrateState> entry : substrateStates.entrySet()) {
            snapshot.put(entry.getKey(), entry.getValue().snapshotCopy());
        }
        for (ChunkPos pos : positions) {
            snapshot.computeIfAbsent(pos, ignored -> new SubstrateState());
        }

        Map<ChunkPos, SubstrateState> nextStates = new HashMap<>();
        for (ChunkPos pos : positions) {
            if (!world.isChunkLoaded(pos.x, pos.z)) {
                continue;
            }
            SubstrateState current = snapshot.get(pos);
            if (current == null) {
                current = new SubstrateState();
            }
            SpatialStencil stencil = SpatialStencil.fromChunkNeighbors(pos, current, snapshot);
            double incomingTransport = SubstrateTransport.computeIncoming(pos, current, parameters, snapshot);
            double externalInput = consumeInstantaneousImpulse(pos);
            if (UTDConfig.substrateGameplayTuningEnabled) {
                externalInput += UTDConfig.substrateLocalTensionBias * getLocalTension(pos);
            }
            SubstrateState next = current.integrateCopy(externalInput, incomingTransport, stencil, parameters);
            nextStates.put(pos, next);
        }

        for (Map.Entry<ChunkPos, SubstrateState> entry : nextStates.entrySet()) {
            substrateStates.put(entry.getKey(), entry.getValue());
            touch(entry.getKey());
            ExperimentLogger.logSubstrateSnapshot(TensionTraceClock.getServerTick(), world, entry.getKey(), entry.getValue());
            if (Boolean.getBoolean("utd.diag.substrate")) {
                DiagnosticLogs.substrateSnapshot(TensionTraceClock.getServerTick(), entry.getKey(), entry.getValue());
            }
        }
        if (!nextStates.isEmpty()) {
            markDirty();
        }
    }

    /**
     * @deprecated use {@link #integrateAllSubstrateStates} for tick integration.
     */
    @Deprecated
    public void updateSubstrateState(ChunkPos pos, double tension, ServerWorld world) {
        integrateAllSubstrateStates(world, List.of(pos));
    }

    public void tickContaminationMemory(ChunkPos pos, double tension, long worldTick) {
        if (tension > 0.56) return;
        int slot = Math.floorMod(pos.x + pos.z * 31, 200);
        if (worldTick % 200 != slot) return;
        Byte lv = contaminationLevel.get(pos);
        if (lv == null || lv <= 0) return;
        if (tension < 0.42) {
            contaminationLevel.put(pos, (byte) (lv - 1));
            markDirty();
        }
    }

    private void updateContaminationMemory(ChunkPos pos, double tension) {
        if (tension <= 0.0) return;
        contaminationPeak.merge(pos, tension, Math::max);
        byte lv = contaminationLevel.getOrDefault(pos, (byte) 0);
        if (tension >= TensionThresholds.CONTAMINATION_HEAVY) {
            contaminationLevel.put(pos, (byte) 2);
        } else if (tension >= TensionThresholds.CONTAMINATION_MEDIUM) {
            contaminationLevel.put(pos, (byte) Math.max(1, lv));
        }
    }

    /**
     * Record access to a chunk for TTL-based pruning.
     */
    private void touch(ChunkPos pos) {
        if (pos == null) return;
        lastAccessMs.put(pos, System.currentTimeMillis());
    }

    /**
     * Prune entries not touched within the given timeout (ms).
     * Returns number of removed chunk entries.
     */
    public int pruneInactive(long timeoutMs) {
        if (timeoutMs <= 0) return 0;
        long now = System.currentTimeMillis();
        int removed = 0;
        java.util.List<ChunkPos> toRemove = new java.util.ArrayList<>();
        for (java.util.Map.Entry<ChunkPos, Long> e : lastAccessMs.entrySet()) {
            ChunkPos pos = e.getKey();
            long age = now - e.getValue();
            // Use derived tension for TTL extension
            SubstrateState ss = substrateStates.get(pos);
            double t = ss != null ? SubstrateObservationModel.computeLocalTension(ss) : 0.0;
            int cLv = getContaminationLevel(pos);
            long effectiveTimeout = timeoutMs;
            if (t >= TensionThresholds.RETENTION_EXTENSION) effectiveTimeout = Math.max(effectiveTimeout, 4L * 60L * 60L * 1000L);
            if (cLv >= 2)  effectiveTimeout = Math.max(effectiveTimeout, 6L * 60L * 60L * 1000L);
            else if (cLv >= 1) effectiveTimeout = Math.max(effectiveTimeout, 5L * 60L * 60L * 1000L);
            if (age > effectiveTimeout) toRemove.add(pos);
        }
        for (ChunkPos pos : toRemove) {
            chunkStates.remove(pos);
            recentMiningRate.remove(pos);
            stormActive.remove(pos);
            lastAccessMs.remove(pos);
            contaminationPeak.remove(pos);
            contaminationLevel.remove(pos);
            substrateStates.remove(pos);
            instantaneousImpulses.remove(pos);
            removed++;
        }
        if (removed > 0) {
            markDirty();
            TensionTraceLogger.traceSystem(
                TensionTraceClock.getServerTick(), "CHUNK_PRUNE",
                "removed=" + removed + " timeoutMs=" + timeoutMs,
                TensionManager.getTension(), "ttl_prune");
        }
        return removed;
    }

    private void triggerStateTransitionEffects(ServerWorld world, ChunkPos pos, ChunkState oldState, ChunkState newState) {
        if (newState == ChunkState.FRACTURED && oldState != ChunkState.DECOUPLED) {
            // Spawn smoke particles in the chunk when it becomes FRACTURED
            for (int i = 0; i < 5; i++) {
                double x = (pos.x << 4) + world.random.nextDouble() * 16;
                double z = (pos.z << 4) + world.random.nextDouble() * 16;
                double y = world.getTopY() + 10; // Above ground level
                // Note: In a real implementation, you'd send particle packets to clients
                // For now, just log
                System.out.printf("[UTDMod] FRACTURED effect: smoke at %.1f, %.1f, %.1f%n", x, y, z);
            }
        }
    }

    private ChunkState calculateState(double tension, ChunkState current) {
        if (tension <= 0) return ChunkState.STABLE;
        if (tension >= T3) return ChunkState.DECOUPLED;
        if (current == ChunkState.DECOUPLED && tension >= T3 - STATE_HYSTERESIS) {
            return ChunkState.DECOUPLED;
        }
        if (tension >= T2) return ChunkState.FRACTURED;
        if (current == ChunkState.FRACTURED && tension >= T2 - STATE_HYSTERESIS) {
            return ChunkState.FRACTURED;
        }
        if (tension >= T1) return ChunkState.STRAINED;
        if (current == ChunkState.STRAINED && tension >= T1 - STATE_HYSTERESIS) {
            return ChunkState.STRAINED;
        }
        return ChunkState.STABLE;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList chunkList = new NbtList();
        for (Map.Entry<ChunkPos, SubstrateState> entry : substrateStates.entrySet()) {
            ChunkPos pos = entry.getKey();
            SubstrateState ss = entry.getValue();
            NbtCompound chunkNbt = new NbtCompound();
            chunkNbt.putInt("x", pos.x);
            chunkNbt.putInt("z", pos.z);
            chunkNbt.putInt("state", getChunkState(pos).ordinal());
            chunkNbt.putDouble("miningRate", recentMiningRate.getOrDefault(pos, 0.0));
            chunkNbt.putDouble("cPeak", contaminationPeak.getOrDefault(pos, 0.0));
            chunkNbt.putByte("cLv", contaminationLevel.getOrDefault(pos, (byte) 0));
            chunkNbt.putBoolean("stormActive", stormActive.getOrDefault(pos, false));
            chunkNbt.putDouble("sActivation", ss.getActivation());
            chunkNbt.putDouble("sMemory", ss.getMemory());
            chunkNbt.putDouble("sTransport", ss.getTransport());
            chunkNbt.putDouble("sFieldDepth", ss.getFieldDepth());
            chunkNbt.putDouble("sBaseline", ss.getBaseline());
            chunkNbt.putDouble("sExternalInput", ss.getExternalInput());
            chunkNbt.putDouble("sReadiness", ss.getReadiness());
            chunkNbt.putDouble("sRadius", ss.getRadius());
            chunkNbt.putDouble("sCapacity", ss.getCapacity());
            chunkNbt.putDouble("sPeakActivation", ss.getPeakActivation());
            chunkNbt.putDouble("sConvergence", ss.getConvergence());
            chunkList.add(chunkNbt);
        }
        nbt.put("substrateChunks", chunkList);
        return nbt;
    }

    public static ChunkTensionData fromNbt(NbtCompound nbt) {
        ChunkTensionData data = new ChunkTensionData();
        // Support both new key and legacy key for forward/backward compat on load
        NbtList chunkList = nbt.contains("substrateChunks")
            ? nbt.getList("substrateChunks", 10)
            : nbt.getList("localTensions", 10);
        for (int i = 0; i < chunkList.size(); i++) {
            NbtCompound chunkNbt = chunkList.getCompound(i);
            int x = chunkNbt.getInt("x");
            int z = chunkNbt.getInt("z");
            ChunkPos pos = new ChunkPos(x, z);
            int stateOrdinal = chunkNbt.getInt("state");
            data.chunkStates.put(pos, ChunkState.values()[stateOrdinal]);
            double miningRate = chunkNbt.getDouble("miningRate");
            if (miningRate > 0) data.recentMiningRate.put(pos, miningRate);
            if (chunkNbt.getBoolean("stormActive")) data.stormActive.put(pos, true);
            if (chunkNbt.contains("cPeak")) data.contaminationPeak.put(pos, chunkNbt.getDouble("cPeak"));
            if (chunkNbt.contains("cLv"))  data.contaminationLevel.put(pos, chunkNbt.getByte("cLv"));
            if (chunkNbt.contains("sActivation")) {
                SubstrateState loaded = new SubstrateState(
                    chunkNbt.getDouble("sActivation"),
                    chunkNbt.getDouble("sMemory"),
                    chunkNbt.getDouble("sTransport"),
                    chunkNbt.getDouble("sFieldDepth"),
                    chunkNbt.contains("sBaseline") ? chunkNbt.getDouble("sBaseline") : 0.0
                );
                loaded.restoreFromPersistence(
                    chunkNbt.getDouble("sActivation"),
                    chunkNbt.getDouble("sMemory"),
                    chunkNbt.getDouble("sTransport"),
                    chunkNbt.getDouble("sFieldDepth"),
                    chunkNbt.contains("sBaseline") ? chunkNbt.getDouble("sBaseline") : 0.0,
                    chunkNbt.contains("sExternalInput") ? chunkNbt.getDouble("sExternalInput") : 0.0,
                    chunkNbt.contains("sReadiness") ? chunkNbt.getDouble("sReadiness") : loaded.getReadiness(),
                    chunkNbt.contains("sRadius") ? chunkNbt.getDouble("sRadius") : loaded.getRadius(),
                    chunkNbt.contains("sCapacity") ? chunkNbt.getDouble("sCapacity") : loaded.getCapacity(),
                    chunkNbt.contains("sPeakActivation") ? chunkNbt.getDouble("sPeakActivation") : loaded.getPeakActivation(),
                    chunkNbt.contains("sConvergence") ? chunkNbt.getDouble("sConvergence") : loaded.getConvergence()
                );
                data.substrateStates.put(pos, loaded);
            }
        }
        return data;
    }
}
