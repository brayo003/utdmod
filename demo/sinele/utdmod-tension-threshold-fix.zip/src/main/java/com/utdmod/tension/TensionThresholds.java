package com.utdmod.tension;

/**
 * Shared thresholds for the bounded local substrate-tension observation T(x).
 * T(x) is a weighted average of normalized non-negative state variables, so it
 * lies in [0, 1) mathematically and is further bounded by the runtime state clamps.
 * These values are an initial reachable-scale calibration, not playtest-validated
 * timing guarantees.
 */
public final class TensionThresholds {
    private TensionThresholds() {}

    public static final double CHUNK_STRAINED = 0.35;
    public static final double CHUNK_FRACTURED = 0.60;
    public static final double CHUNK_DECOUPLED = 0.72;
    public static final double CHUNK_HYSTERESIS = 0.08;

    public static final double REGION_STRAINED = 0.45;
    public static final double REGION_FRACTURED = 0.60;
    public static final double ECOLOGY_STRAINED = 0.65;

    public static final double CONTAMINATION_MEDIUM = 0.55;
    public static final double CONTAMINATION_HEAVY = 0.68;
    public static final double RETENTION_EXTENSION = 0.70;

    public static final double SLEEP_BLOCK = 0.60;
    public static final double WRAITH_AGGRESSION = 0.60;
}
