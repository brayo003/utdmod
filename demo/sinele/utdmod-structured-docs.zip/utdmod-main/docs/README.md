# UTD Mod Documentation

This directory separates the current architecture specification from audit material and historical records.

## Current architecture

The canonical implementation-facing documentation is in `architecture/`.

- `SUMMARY.md` — current substrate architecture.
- `SYSTEM_OVERVIEW.md` — system-level overview.
- `EQUATIONS.md` — current implementation-backed equations.
- `PARAMETER_CATALOG.md` — current runtime parameter reference.
- `00_EXECUTION_PIPELINE.md` through `11_PERFORMANCE.md` — ordered subsystem documentation.

## Architecture audit

`architecture_audit/` contains implementation audits, evidence registers, dependency/call graphs, stability analysis, test-harness documentation, diagnostics, and verification material.

## Archive

`archive/` contains historical or generated material retained for provenance. The pre-refactor scalar-equation documents are archived here and are not the current mathematical reference.

## Documentation rule

When current documentation conflicts with historical material, the current implementation-backed documents under `architecture/` are the reference. Historical documents are retained as the project development and audit trail.
