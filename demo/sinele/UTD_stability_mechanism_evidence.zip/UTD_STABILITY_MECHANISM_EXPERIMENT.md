# UTD corrected dynamics — experimental stability mechanism test

## Decision question
Can an explicit stability/order quantity make an organized chunk respond less to a repeated disturbance than a virgin chunk, while leaving the corrected baseline equations and anti-diffusion removal untouched?

## What “stability” means in this test
For this experiment only, stability `S` is a dimensionless structural-resistance value in `[0,1]`, not an existing UTD field. It reduces the portion of a new external disturbance that enters the activation equation:

`effectiveInput = externalInput * (1 - rho * S)`

`rho` controls maximum resistance. This mechanism models *resistance to new disturbance*. It does not freeze the region, alter memory diffusion, or reintroduce anti-diffusion. It does not yet model how S is earned or lost; that is a separate design decision and must not be smuggled in as if tested.

## Method
- Used the corrected ZIP's actual Java simulation-lab equations (`GridSimulationV2`, `FieldDerivative`, `SpatialStencil`, `ParameterSet`) with anti-diffusion absent.
- A temporary test harness changed only the external-input value passed to the existing derivative; no source files in the original ZIP were modified.
- 5×5 grid; 20 ticks of repeated input `0.05` at the center, followed by 20 ticks without input.
- Each input run had a paired no-input control with the same initial state. “Input-attributable ΔA at tick 20” is the center activation with input minus center activation without input, not raw activation.
- Tested virgin `(A=0, M=0, D=0, B=0.02, S=0)`, organized candidate `(A=0.02, M=0.50, D=0.80, B=0.80, S=0.90)`, and overstressed candidate `(A=0.35, M=0.45, D=0.75, B=0.70, S=0.15)`. State values are controlled test profiles within the lab clamp, not calibrated Minecraft chunk measurements.
- Swept `rho` from 0 to 0.95. Full results are in `UTD_experimental_stability_results.csv`.

## Key results

| Case | rho | Stability S | Input-attributable ΔA after 20 input ticks | Relative to virgin |
|---|---:|---:|---:|---:|
| Virgin | 0.60 | 0.00 | 0.019102 | 1.00× |
| Organized candidate | 0.50 | 0.90 | 0.021413 | 1.12× |
| Organized candidate | 0.55 | 0.90 | 0.019663 | 1.03× |
| Organized candidate | 0.60 | 0.90 | 0.017913 | 0.94× |
| Organized candidate | 0.75 | 0.90 | 0.012659 | 0.66× |
| Overstressed candidate | 0.60 | 0.15 | 0.034476 | 1.80× |

At `rho=0.60`, the organized candidate's input-attributable response is about 6.2% lower than virgin. The tested crossover lies between `rho=0.55` and `rho=0.60` for this particular initial profile. At `rho=0.75`, it is about 33.7% lower. The low-stability overstressed profile still responds about 1.8× as strongly as virgin at `rho=0.60`, reflecting its existing state-dependent susceptibility and higher initial activation.

After the 20-tick input stops, the input-attributable activation difference at tick 40 is approximately zero for all cases (`~1e-7` to `~5e-7`). In this lab configuration, ordinary activation decay already removes this short pulse's activation trace over the next 20 ticks. The resistance mechanism primarily changes the size of the response, not the recovery rate.

## Verdict
**Feasibility test: PASS. Design validation: NOT YET.** An explicit stability-resistance term can create the desired C-like weaker response without anti-diffusion. The test also shows that the resistance strength matters: a small coefficient does not overcome the existing susceptibility increase from high memory/depth/baseline; the crossover in this example is between 0.55 and 0.60.

This is not evidence that the mechanic is ready to merge. `S` is currently a test-only parameter, not an existing substrate state; the numerical profiles and coefficient are not calibrated to gameplay. A proper next test should define how structural order accumulates and erodes, ensure it cannot become a permanent invulnerability switch, and run multi-pulse / recovery / neighboring-chunk tests against the unmodified corrected baseline.

## Files and reproducibility
- Results CSV: `UTD_experimental_stability_results.csv`
- Temporary harness was created outside the original ZIP's source baseline in the working extraction. No project source files were changed by this experiment.
- This is a Java simulation-lab test, not a live Minecraft server test. The input amount is a controlled proxy, not “20 mined blocks” calibrated in-game.
